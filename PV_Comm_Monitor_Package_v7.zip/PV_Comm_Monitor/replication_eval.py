"""Replication on a regenerated main dataset (second review: time-label offset and SAM-version confounds).
The four scenarios of the main dataset are re-exported from the same SAM model as the severity runs (Tripoli, NSRDB 2019, same
labels convention): normal, soiling 25 %, DC wiring 10 %, and the 6 kW inverter (Fronius Primo GEN24 6.0 Plus).
No record carries a communication-loss flag here, so all 34,764 daylight records (GHI > 0) are used.
Same features, network, week-blocked folds and week-cluster bootstrap as evaluate.py / extra_eval.py.
Usage: python replication_eval.py out.json"""
import sys, json
import numpy as np, pandas as pd
from sklearn.metrics import confusion_matrix
import pvmon_core as C

OUT = sys.argv[1] if len(sys.argv) > 1 else 'replication_results.json'
FILES = [('sam_runs/w1_normal_default.csv', 0), ('sam_runs/w1_soiling_25.csv', 1), ('sam_runs/w1_dcwiring_10.csv', 2), ('sam_runs/w1_inv_6kw.csv', 3)]
parts = []
for f, lab in FILES:
    r = pd.read_csv(f).rename(columns={v: k for k, v in C.SRC_COLS.items()}); r['ts'] = C.parse_ts(r['ts'])
    r = r[['ts'] + C.RAW].copy(); r['Label'] = lab; parts.append(r[r['GHI'] > 0].reset_index(drop=True))
d = pd.concat(parts, ignore_index=True); y = d['Label'].values
F = pd.concat([C.build_features(p) for p in parts], ignore_index=True)
fold = C.week_folds(d); wk = ((d['ts'].dt.dayofyear - 1) // 7).values
R = {'n': int(len(d)), 'per_class': {int(k): int(v) for k, v in pd.Series(y).value_counts().sort_index().items()}}

def stats(p, B=2000, seed=0):
    weeks = np.unique(wk); cms = np.array([confusion_matrix(y[wk == w], p[wk == w], labels=[0, 1, 2, 3]) for w in weeks])
    rng = np.random.default_rng(seed); out = []
    for _ in range(B):
        cm = cms[rng.integers(0, len(weeks), len(weeks))].sum(0)
        rec = np.diag(cm) / np.maximum(cm.sum(1), 1); prec = np.diag(cm) / np.maximum(cm.sum(0), 1)
        f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-9); out.append([np.trace(cm) / cm.sum(), f1.mean()])
    lo, hi = np.percentile(np.array(out), [2.5, 97.5], axis=0)
    cm = confusion_matrix(y, p, labels=[0, 1, 2, 3]); rec = np.diag(cm) / cm.sum(1); prec = np.diag(cm) / cm.sum(0)
    return {'accuracy': float(np.trace(cm) / cm.sum()), 'accuracy_ci': [float(lo[0]), float(hi[0])],
            'macro_f1': float((2 * prec * rec / (prec + rec)).mean()), 'macro_f1_ci': [float(lo[1]), float(hi[1])],
            'recall': [float(x) for x in rec], 'confusion': cm.tolist()}

for name, feats in (('all_16_features', C.FEATURES), ('without_clipping_variables', [f for f in C.FEATURES if f not in ('clp', 'clp_DC')])):
    pred = np.zeros(len(d), int)
    for k in range(C.N_FOLDS):
        t = fold != k
        pred[~t] = C.make_model().fit(F.loc[t, feats].values, y[t]).predict(F.loc[~t, feats].values)
    R['blocked_' + name] = stats(pred)
    tr, te = C.split_chronological(d)
    m = C.make_model().fit(F.loc[tr, feats].values, y[tr])
    R['chronological_' + name] = float((m.predict(F.loc[te, feats].values) == y[te]).mean())
    print(name, R['blocked_' + name]['accuracy'], R['chronological_' + name], flush=True)

# clipping variable: share of non-zero values per class, regenerated vs original files
R['clip_nonzero_share_regenerated'] = {int(l): float((d.loc[d.Label == l, 'clp'].abs() > 1e-6).mean()) for l in range(4)}
o = C.load_clean('Solar_Fault_Dataset_With_Comm_Loss_No_New_Label.csv'); o = o[o['GHI'] > 0]
R['clip_nonzero_share_original'] = {int(l): float((o.loc[o.Label == l, 'clp'].abs() > 1e-6).mean()) for l in range(4)}
R['clip_max_regenerated'] = float(d['clp'].max()); R['clip_max_original'] = float(o['clp'].max())
json.dump(R, open(OUT, 'w'), indent=1)
