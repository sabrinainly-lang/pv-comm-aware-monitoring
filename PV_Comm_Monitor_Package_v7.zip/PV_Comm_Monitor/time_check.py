"""Time-convention check (second review, item 1).
The four scenario files of the main dataset carry time labels that are two hours earlier than the labels of a SAM export of the
same weather file. Hour of day and solar declination are model inputs, so the offset can matter when a model is moved between the
original data and regenerated runs.  Two checks, both with the final features and the final network (random state 42):
 A. within the main dataset: week-blocked 5-fold accuracy with the original labels and with all labels shifted by +2 h;
 B. frozen model: trained on the whole main dataset, applied to regenerated Tripoli runs that use the same loss settings
    (normal, soiling 25 %, DC wiring 10 %; the 6 kW inverter scenario has no regenerated counterpart), once with the labels of the
    SAM export as they are ('offset left in place') and once shifted by -2 h ('aligned with the original labels').
Usage: python time_check.py out.json"""
import sys, json
import numpy as np, pandas as pd
import pvmon_core as C

out = sys.argv[1] if len(sys.argv) > 1 else 'time_results.json'
D = C.load_clean('Solar_Fault_Dataset_With_Comm_Loss_No_New_Label.csv')
D = D[D['GHI'] > 0].reset_index(drop=True)

def feats(df):
    F = C.build_features(df); return F

R = {}
# A. within-dataset
for name, shift in (('original_labels', 0), ('shifted_plus_2h', 2)):
    d = D.copy(); d['ts'] = d['ts'] + pd.Timedelta(hours=shift)
    F = feats(d); fold = C.week_folds(d); y = d['Label'].values; pred = np.zeros(len(d), int)
    for k in range(5):
        trn = fold != k
        m = C.make_model().fit(F.loc[trn, C.FEATURES].values, y[trn]); pred[~trn] = m.predict(F.loc[~trn, C.FEATURES].values)
    tr, te = C.split_chronological(d)
    mc = C.make_model().fit(F.loc[tr, C.FEATURES].values, y[tr])
    R['within_' + name] = {'blocked_accuracy': float((pred == y).mean()),
                           'chronological_accuracy': float((mc.predict(F.loc[te, C.FEATURES].values) == y[te]).mean())}
# B. frozen model on regenerated runs
F = feats(D); frozen = C.make_model().fit(F[C.FEATURES].values, D['Label'].values)
runs = [('sam_runs/w1_normal_default.csv', 0), ('sam_runs/w1_soiling_25.csv', 1), ('sam_runs/w1_dcwiring_10.csv', 2)]
for name, shift in (('offset_left_in_place', 0), ('aligned_minus_2h', -2)):
    parts = []
    for f, lab in runs:
        r = pd.read_csv(f).rename(columns={v: k for k, v in C.SRC_COLS.items()})
        r['ts'] = C.parse_ts(r['ts']) + pd.Timedelta(hours=shift)
        r = r[['ts'] + C.RAW].copy(); r['Label'] = lab
        r = r[r['GHI'] > 0].reset_index(drop=True); parts.append(r)
    A = pd.concat(parts, ignore_index=True)
    FA = pd.concat([C.build_features(p) for p in parts], ignore_index=True)
    p = frozen.predict(FA[C.FEATURES].values); y = A['Label'].values
    R['frozen_' + name] = {'accuracy': float((p == y).mean()), 'n': int(len(y)),
                           'per_class_recall': {int(c): float((p[y == c] == c).mean()) for c in (0, 1, 2)}}
json.dump(R, open(out, 'w'), indent=1); print(json.dumps(R, indent=1))
